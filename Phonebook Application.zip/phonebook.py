import tkinter as tk
from tkinter import messagebox, Listbox, END

class PhonebookApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Phonebook Application")
        
        # Initialize contacts list
        self.contacts = {}

        # Create UI elements
        self.create_widgets()

    def create_widgets(self):
        # Labels
        tk.Label(self.root, text="Name:").grid(row=0, column=0, padx=5, pady=5)
        tk.Label(self.root, text="Phone Number:").grid(row=1, column=0, padx=5, pady=5)
        tk.Label(self.root, text="Email:").grid(row=2, column=0, padx=5, pady=5)

        # Entry fields
        self.name_entry = tk.Entry(self.root)
        self.name_entry.grid(row=0, column=1, padx=5, pady=5)

        self.phone_entry = tk.Entry(self.root)
        self.phone_entry.grid(row=1, column=1, padx=5, pady=5)

        self.email_entry = tk.Entry(self.root)
        self.email_entry.grid(row=2, column=1, padx=5, pady=5)

        # Listbox to display contacts
        self.contact_listbox = Listbox(self.root, width=50)
        self.contact_listbox.grid(row=3, column=0, columnspan=2, padx=5, pady=5)

        # Buttons
        tk.Button(self.root, text="Add Contact", command=self.add_contact).grid(row=4, column=0, padx=5, pady=5)
        tk.Button(self.root, text="Delete Contact", command=self.delete_contact).grid(row=4, column=1, padx=5, pady=5)

        tk.Button(self.root, text="Search Contact", command=self.search_contact).grid(row=5, column=0, columnspan=2, padx=5, pady=5)

    def add_contact(self):
        name = self.name_entry.get()
        phone = self.phone_entry.get()
        email = self.email_entry.get()

        if name and phone:  # Ensure name and phone number are provided
            self.contacts[name] = (phone, email)
            self.update_contact_list()
            self.clear_entries()
        else:
            messagebox.showwarning("Input Error", "Name and Phone Number are required.")

    def delete_contact(self):
        selected_contact = self.contact_listbox.curselection()
        if selected_contact:
            contact_name = self.contact_listbox.get(selected_contact)
            del self.contacts[contact_name]
            self.update_contact_list()
        else:
            messagebox.showwarning("Selection Error", "Please select a contact to delete.")

    def search_contact(self):
        name = self.name_entry.get()
        if name in self.contacts:
            phone, email = self.contacts[name]
            messagebox.showinfo("Contact Found", f"Name: {name}\nPhone: {phone}\nEmail: {email}")
        else:
            messagebox.showinfo("Not Found", "Contact not found.")

    def update_contact_list(self):
        self.contact_listbox.delete(0, END)
        for contact in self.contacts.keys():
            self.contact_listbox.insert(END, contact)

    def clear_entries(self):
        self.name_entry.delete(0, END)
        self.phone_entry.delete(0, END)
        self.email_entry.delete(0, END)

# Create the main application window
if __name__ == "__main__":
    root = tk.Tk()
    # screen_width = root.winfo_screenwidth()
    # screen_height = root.winfo_screenheight()
    # window_width = int(screen_width * 0.75)
    # window_height = int(screen_height * 0.75)
    # root.geometry(f"{window_width}x{window_height}")
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()

# Set the desired window width and height (adjust as needed)
    window_width = 600
    window_height = 400

# Calculate the position to center the window
    center_x = int(screen_width/2 - window_width/2)
    center_y = int(screen_height/2 - window_height/2)

# Set the window size and position
    root.geometry(f"{window_width}x{window_height}+{center_x}+{center_y}")

 
    app = PhonebookApp(root)
    root.mainloop()
